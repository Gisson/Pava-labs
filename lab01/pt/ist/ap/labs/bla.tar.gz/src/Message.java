package pt.ist.ap.labs;

public interface Message{
	public void say();
}
