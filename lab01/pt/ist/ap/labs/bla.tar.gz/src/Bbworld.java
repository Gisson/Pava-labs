package pt.ist.ap.labs;


public class Bbworld implements Message{

	public void say(){
		System.out.println("Dont tell me what to do!");
	}

}
