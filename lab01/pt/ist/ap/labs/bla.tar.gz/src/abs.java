package pt.ist.ap.labs;

public abstract class abs implements Message{}
